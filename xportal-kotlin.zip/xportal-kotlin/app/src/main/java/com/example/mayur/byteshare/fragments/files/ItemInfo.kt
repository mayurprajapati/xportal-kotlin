package com.example.mayur.xportal.fragments.files

class ItemInfo internal constructor(
    var isSelected: Boolean,
    var fileName: String?,
    var absolutePath: String?
)
