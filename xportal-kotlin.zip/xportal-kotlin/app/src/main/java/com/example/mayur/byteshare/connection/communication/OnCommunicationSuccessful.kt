package com.example.mayur.xportal.connection.communication

interface OnCommunicationSuccessful {
    fun onCommunicationSuccessful(deviceName: String)
}
