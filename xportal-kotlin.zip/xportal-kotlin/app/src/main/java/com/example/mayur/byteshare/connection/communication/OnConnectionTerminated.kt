package com.example.mayur.xportal.connection.communication

interface OnConnectionTerminated {
    fun onCommunicationTerminated()
}
