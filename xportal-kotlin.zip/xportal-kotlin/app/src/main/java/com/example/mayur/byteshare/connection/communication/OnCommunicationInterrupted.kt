package com.example.mayur.xportal.connection.communication

interface OnCommunicationInterrupted {
    fun onCommunicationInterrupted()
}
